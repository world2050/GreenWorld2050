 $(document).ready(function() {
    $('[data-toggle=offcanvas]').click(function() {
        $(this).toggleClass('visible-xs text-center');
        $(this).find('i').toggleClass('glyphicon-chevron-right glyphicon-chevron-left');
        $('.row-offcanvas').toggleClass('active');
        $('#lg-menu').toggleClass('hidden-xs').toggleClass('visible-xs');
        $('#xs-menu').toggleClass('visible-xs').toggleClass('hidden-xs');
        $('#btnShow').toggle();
    });
});


/* File upload */
$("#uploadFile").change(function(){
     $('#image_preview').html("");
     var total_file=document.getElementById("uploadFile").files.length;


     for(var i=0;i<total_file;i++)
     {
      $('#image_preview').append("<img class='img img-thumbnail'  src='"+URL.createObjectURL(event.target.files[i])+"'>");
     }

      $('form').ajaxForm(function() 
       {
        alert("Uploaded SuccessFully");
       }); 


});

// Fetch and display video for preview
function load_video( ){
     var videoLink= $('#videoLink').val() 
     if (videoLink != "") {
         videoLink="https://www.youtube.com/embed/"+videoLink+"?autoplay=1";
        $('#image_preview').append("<iframe  class='img vlink'  src='"+videoLink+"?autoplay=1'> </iframe>");
      }

}

// Submit Signup Form
function submitNewForm(){
    var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    var name = $('#newInputName').val();
    var phone = $('#newInputPhone').val();
    var email = $('#newInputEmail').val();
    var town = $('#newInputTown').val();
    var password = $('#newInputPasword').val(); 
    if(name.trim() == '' ){
        alert('Please enter your name.');
        $('#newInputName').focus();
        return false;
    }else if(phone.trim() == '' ){
        alert('Please enter your phone number.');
        $('#newInputPhone').focus();
        return false;
    }else if(email.trim() != '' && !reg.test(email)){
        alert('Please enter valid email.');
        $('#newInputEmail').focus();
        return false;
    }else if(town.trim() == '' ){
        alert('Please enter your current town.');
        $('#newInputTown').focus();
        return false;
    }
    else if(password.trim() == '' ){
        alert('Please enter your current town.');
        $('#newInputPasword').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'signup.php',
            data:'signupFrmSubmit=1&name='+name+'&phone='+phone+'&email='+email+'&town='+town+'&password='+password,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
                if(msg == 'ok'){
                    $('#newInputName').val('');
                    $('#newInputEmail').val('');
                    $('#newInputTown').val();
                    $('#newInputPasword').val();
                    $('.statusMsg').html('<span style="color:green;">Thanks for contacting us, we\'ll get back to you soon.</p>');
                }else{
                    $('.statusMsg').html('<span style="color:red;">Some problem occurred, please try again. </span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
            }
        });
    }
}


// Submit Login Form
function submitLoginForm(){
    var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i; 
    var email = $('#inputEmail').val(); 
    var password = $('#inputPasword').val(); 
    
    if(email.trim() == '' ){
        alert('Please enter your email.');
        $('#inputEmail').focus();
        return false;
    }else if(email.trim() != '' && !reg.test(email)){
        alert('Please enter valid email.');
        $('#inputEmail').focus();
        return false;
    } 
    else if(password.trim() == '' ){
        alert('Please enter your current town.');
        $('#inputMessage').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'login.php',
            data:'loginFrmSubmit=1&email='+email+'&password='+password,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
                if(msg == 'ok'){
                    $('#inputName').val('');
                    $('#inputEmail').val('');
                    $('#inputMessage').val('');
                    $('.statusMsg').html('<span style="color:green;">You are now loged in.</p>');
                }else{
                    $('.statusMsg').html('<span style="color:red;">Some problem occurred, please try again.  </span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
            }
        });
    }
}



// Submit New Post

function submitPost(){
    var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    var title = $('#postTitle').val();
    var content = $('postContent').val(); 
    var location = $('#location').val(); 
    var media = $('#uploadFile').val();  

    var content = document.getElementById('postContent').value; 

    
    if(title.trim() == '' ){
        alert('Please choose a title for your post.');
        $('#postTitle').focus();
        return false;
    }else if(content.trim() == '' ){
        alert('Please write a little about your post.');
        $('#postContent').focus();
        return false;
    }else if(location.trim() == '' ){
        alert('Please add your location using the location icon below the post.');
        $('#postContent').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'posts.php',
            data:'postFrmSubmit=1&title='+title+'&content='+content+'&uploadFile='+media+'&location='+location,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
                if(msg == 'ok'){
                    $('#inputName').val('');
                    $('#inputEmail').val('');
                    $('#inputMessage').val('');
                    $('.postMsg').html('<span style="color:green;">Thanks for sharing with the community us.</p>');
                }else{
                    $('.postMsg').html('<span style="color:red;">Some problem occurred, please try again.<br>'+msg+'</span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
            }
        });
    }
}


 

// Upload media files
$(document).ready(function(){  
      $('#postForm').on('submit', function(e){  
           e.preventDefault(); 
           alert("newCommunity ");

            var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
            var title = $('#postTitle').val();
            var content = $('postContent').val(); 
            var location = $('#location').val(); 
            var media = $('#uploadFile').val();  

            var content = document.getElementById('postContent').value; 

            
            if(title.trim() == '' ){
                alert('Please enter the title of your initiative.');
                $('#postTitle').focus();
                return false;
            }else if(content.trim() == '' ){
                alert('Please describe this initiative.');
                $('#postContent').focus();
                return false;
            }else if(location.trim() == '' ){
                alert('Please add your location using the location icon below the post.');
                $('#postContent').focus();
                return false;
            }else{
                $.ajax({ 
                    url:'posts.php',   
                    type: "POST",  
                    data: new FormData(this),  
                    contentType: false,  
                    processData:false,  
                    beforeSend: function () {
                        $('.submitBtn').attr("disabled","disabled");
                        $('.modal-body').css('opacity', '.5');
                    },
                    success:function(msg){
                        if(msg == 'ok'){
                            $('#postTitle').val('Success fully submited');
                            $('#inputEmail').val('');
                            $('#inputMessage').val('');
                            $('.postMsg').html('<span style="color:green;">Thanks for sharing with the community us.</p>');
                        }else{
                            $('.postMsg').html('<span style="color:red;">Some problem occurred, please try again.<br>'+msg+'</span>');
                        }
                        $('.submitBtn').removeAttr("disabled");
                        $('.modal-body').css('opacity', '');
                    }
                });
            }
           /*****************************************************************/
         
      });  
 });  


 

// Upload media files
$(document).ready(function(){  
      $('#newCommunity').on('submit', function(e){  
           e.preventDefault(); 
           alert("newCommunity ");

            var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
            var title = $('#postTitle').val();
            var content = $('postContent').val(); 
            var location = $('#location').val(); 
            var media = $('#uploadFile').val();  

            var content = document.getElementById('postContent').value; 

            
            if(title.trim() == '' ){
                alert('Please enter the New Community name.');
                $('#postTitle').focus();
                return false;
            }else if(content.trim() == '' ){
                alert('Please write somthing about this community.');
                $('#postContent').focus();
                return false;
            }else if(location.trim() == '' ){
                alert('Please add your location using the location icon below the post.');
                $('#postContent').focus();
                return false;
            }else{
                $.ajax({ 
                    url:'addNewCommunity.php',   
                    type: "POST",  
                    data: new FormData(this),  
                    contentType: false,  
                    processData:false,  
                    beforeSend: function () {
                        $('.submitBtn').attr("disabled","disabled");
                        $('.modal-body').css('opacity', '.5');
                    },
                    success:function(msg){
                        if(msg == 'ok'){
                            $('#postTitle').val('Success fully submited');
                            $('#inputEmail').val('');
                            $('#inputMessage').val('');
                            $('.postMsg').html('<span style="color:green;">Thanks for sharing with the community us.</p>');
                        }else{
                            $('.postMsg').html('<span style="color:red;">Some problem occurred, please try again.<br>'+msg+'</span>');
                        }
                        $('.submitBtn').removeAttr("disabled");
                        $('.modal-body').css('opacity', '');
                    }
                });
            }
           /*****************************************************************/
         
      });  
 });  



// Community Conversation posts handler
$(document).ready(function() {
    $('[data-toggle=offcanvas]').click(function() {
        $(this).toggleClass('visible-xs text-center');
        $(this).find('i').toggleClass('glyphicon-chevron-right glyphicon-chevron-left');
        $('.row-offcanvas').toggleClass('active');
        $('#lg-menu').toggleClass('hidden-xs').toggleClass('visible-xs');
        $('#xs-menu').toggleClass('visible-xs').toggleClass('hidden-xs');
        $('#btnShow').toggle();
    });
}); 

$(".messages").animate({ scrollTop: $(document).height() }, "fast");

$("#profile-img").click(function() {
    $("#status-options").toggleClass("active");
});

$(".expand-button").click(function() {
  $("#profile").toggleClass("expanded");
    $("#contacts").toggleClass("expanded");
});

$("#status-options ul li").click(function() {
    $("#profile-img").removeClass();
    $("#status-online").removeClass("active");
    $("#status-away").removeClass("active");
    $("#status-busy").removeClass("active");
    $("#status-offline").removeClass("active");
    $(this).addClass("active");
    
    if($("#status-online").hasClass("active")) {
        $("#profile-img").addClass("online");
    } else if ($("#status-away").hasClass("active")) {
        $("#profile-img").addClass("away");
    } else if ($("#status-busy").hasClass("active")) {
        $("#profile-img").addClass("busy");
    } else if ($("#status-offline").hasClass("active")) {
        $("#profile-img").addClass("offline");
    } else {
        $("#profile-img").removeClass();
    };
    
    $("#status-options").removeClass("active");
});


function newMessage(e) { 
    e.preventDefault(); 


    
    message = $(".message-input input").val();
    if($.trim(message) == '') {
        return false; 
    }

    var  community =  $("#postCommunity").val();
    var  postId = $("#postId").val();
     
    $.ajax({
        type:'POST',
        url:'sendMsg.php',
        data:'submitMsg=1&msg='+message+'&community='+community+'&postId='+postId,
        beforeSend: function () {
                $('<li class="sent"><img src="http://emilcarlsson.se/assets/mikeross.png" alt="" /><p>' + message + '</p></li>').appendTo($('.messages ul'));
                $('.message-input input').val(null);
                $('.contact.active .preview').html('<span>You: </span>' + message);
                $(".messages").animate({ scrollTop: $(document).height() }, "fast");

        },
        success:function(msg){
            if(msg == 'ok'){
                $('.contact.active .preview').html('<span>You: </span>' + message); 
                $(".messages").animate({ scrollTop: $('.inbox').innHeight() }, "fast"); 
            }else{
                $('.postMsg').html('<span style="color:red;">Some problem occurred, please try again.</span>'); 
            } 
        }
    });


};
function updateChats(){

    $.ajax({
        type:'POST',
        url:'sendMsg.php',
        data:'getMsgs=1',
        beforeSend: function () {
               

        },
        success:function(msg){ 
            var newMsg = msg;

            if(newMsg =="skip"){
                // do nothing 
                 return;
            }else{ 
                $('<li class="replies"><img src="assets/img/user-avatar-640x640.png" alt="" /><p>' + newMsg + '</p></li>').appendTo($('.messages ul'));
                 
            } 
        }
    });
}

$('.submit').click(function(e) {
  newMessage(e);
});

$(window).on('keydown', function(e) {
  if (e.which == 13) {
    newMessage(e);
    return false;
  }
});


 // Enable tooltips
 // $(function () {
 // $('[data-toggle="tooltip"]').tooltip()
//});

/////////////////----------------->   document.getElementById("myForm").reset();