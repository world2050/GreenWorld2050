name = "patrick"

age =24

print(type(age))